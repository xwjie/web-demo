export * from './trim/trim.pipe';
