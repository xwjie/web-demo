/*global enyo:false */
enyo.depends(
	'controllers',
	'models',
	'collections',
	'views',
	'apps',
	'start.js'
);
