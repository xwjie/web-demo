/*global define */
define({
	edit: 'Double-click to edit a todo',
	templateBy: 'Template by',
	createdBy: 'Created by',
	partOf: 'Part of'
});
